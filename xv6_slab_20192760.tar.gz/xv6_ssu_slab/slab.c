#include "types.h"
#include "defs.h"
#include "param.h"
#include "memlayout.h"
#include "mmu.h"
#include "spinlock.h"
#include "slab.h"

struct {
	struct spinlock lock;
	struct slab slab[NSLAB];
} stable;

void slabinit(){
	/* fill in the blank */
	struct slab *s;
		
	acquire(&stable.lock);
	int slabsize = 8;
	int ob = 512;
	for(s = stable.slab; s < &stable.slab[NSLAB]; s++) {
		s->size = slabsize;
		s->num_free_objects = ob;
		s->page[0] = kalloc();
		s->num_pages = 1;
		s->num_used_objects = 0;
		s->bitmap = kalloc();
		memset(s->bitmap, 0, 4096);
		s->num_objects_per_page = ob;
		slabsize = slabsize * 2;
		ob = ob / 2;
	}
	release(&stable.lock);
}

char *kmalloc(int size){
	acquire(&stable.lock);
	struct slab *s;
	/* fill in the blank */
	int count = 0;
	int result = 0;
	while (size != 0) {
		size >>=1;
		count += 1;
	}
	result = 1 << count;
	char *r_address = 0;
	
	for(s = stable.slab; s < &stable.slab[NSLAB]; s++) {
		if (s->size == result) {
				if( s->num_free_objects <= 0) {
					s->num_free_objects = s->num_objects_per_page;
					s ->num_pages ++;
					s->page[s->num_pages-1] = kalloc();
				}
				int start = (s-> num_pages-1) * s-> num_objects_per_page;
				int end = (s -> num_pages - 1) * s -> num_objects_per_page + (s -> num_objects_per_page -1);
				
				for(; start < end; start++) {
					char *addr = s->bitmap + start;
					if (*addr== 0) {
						memset(s->bitmap + start,1,1);
						break;
					}
				}
			s->num_free_objects --;
			s->num_used_objects ++;
			r_address = s->page[s->num_pages-1] + (start * s->size);
		}
	}
	//cprintf("%d\t", address);
	release(&stable.lock);

	return r_address;
}

void kmfree(char *addr, int size){
	/* fill in the blank */
	acquire(&stable.lock);
	struct slab *s;
	int count = 0;
	int result = 0;

	while (size != 0) {
		size >>= 1;
		count+= 1;
	}
	result = 1 << count;	
	for(s=stable.slab; s < &stable.slab[NSLAB]; s++) {
		if (s -> size == result) {
			s -> num_free_objects ++;
			s -> num_used_objects --;
		}
		int end = (s->num_pages -1) * s -> num_objects_per_page + (s -> num_objects_per_page -1);
		for(; end >= 0; end--) {
			char *address = s->bitmap + end;
			if ( addr == address)
				memset(s->bitmap + end,0,1);
		}
	}
	release(&stable.lock);
}

void slabdump(){
	cprintf("__slabdump__\n");

	struct slab *s;

	cprintf("size\tnum_pages\tused_objects\tfree_objects\n");

	for(s = stable.slab; s < &stable.slab[NSLAB]; s++){
		cprintf("%d\t%d\t\t%d\t\t%d\n", 
			s->size, s->num_pages, s->num_used_objects, s->num_free_objects);
	}
}	
